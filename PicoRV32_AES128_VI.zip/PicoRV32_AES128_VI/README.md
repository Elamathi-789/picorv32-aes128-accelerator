# AES-128 Decryption RTL

Built to match the supplied AES-128 encryption design.

Files:
- inv_sbox.v
- inv_subbytes.v
- inv_shiftrows.v
- inv_mix_single_column.v
- inv_mix_columns.v
- aes_v3_decrypt_round.v
- aes_v3_decrypt_final_round.v
- aes_v3_decrypt_top.v
- aes_v3_decrypt_tb.v

The top-level decryption block uses the existing `keyexpansion.v`.
Round keys are generated K1..K10 and consumed in reverse order.

Standard test:
Ciphertext = 69C4E0D86A7B0430D8CDB78070B4C55A
Key        = 000102030405060708090A0B0C0D0E0F
Expected   = 00112233445566778899AABBCCDDEEFF

IMPORTANT:
Run the existing encryption test first, then this decryption test.
After both pass, we will create a combined encrypt/decrypt top and
then the PicoRV32 MMIO wrapper.
